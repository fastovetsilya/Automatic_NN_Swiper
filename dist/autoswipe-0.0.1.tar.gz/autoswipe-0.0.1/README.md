# Automatic_NN_Swiper

## Description
Automatic swiping tool for dating sites. The current version is available for Bumble only. 


## Installation 
In Linux run:
```console
$ git clone https://github.com/fastovetsilya/Automatic_NN_Swiper
$ cd Automatic_NN_Swiper/ 
$ pip install .
```




